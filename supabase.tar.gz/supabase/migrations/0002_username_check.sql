-- =========================================================================
-- Lyra 0002 :: username uniqueness check RPC
-- Callable by anon so the Sign Up screen can validate before submit.
-- =========================================================================

create or replace function public.username_available(_username text)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select
    _username is not null
    and length(trim(_username)) >= 3
    and not exists (
      select 1 from public.profiles
      where lower(username) = lower(trim(_username))
    );
$$;

grant execute on function public.username_available(text) to anon, authenticated;
