-- =========================================================================
-- Lyra — Instagram-like social app :: initial schema + RLS policies
-- Run this against your Supabase project (SQL Editor or `supabase db push`).
-- Idempotent where possible so it can be re-run safely.
-- =========================================================================

-- Extensions ---------------------------------------------------------------
create extension if not exists "pgcrypto";

-- 1. profiles --------------------------------------------------------------
-- Linked 1:1 with auth.users. Username is globally unique.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  email text,
  full_name text,
  avatar_url text,
  bio text,
  is_email_verified boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists idx_profiles_username on public.profiles (lower(username));

-- Auto-create profile row when a new auth user is inserted.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  new_username text;
begin
  new_username := coalesce(
    nullif(new.raw_user_meta_data->>'username', ''),
    'user_' || substr(new.id::text, 1, 8)
  );
  insert into public.profiles (id, username, email, is_email_verified)
  values (new.id, new_username, new.email, new.email_confirmed_at is not null)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Keep is_email_verified in sync when a user confirms their email.
create or replace function public.handle_user_email_confirmed()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if (new.email_confirmed_at is not null and old.email_confirmed_at is null) then
    update public.profiles
      set is_email_verified = true, updated_at = now()
      where id = new.id;
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_email_confirmed on auth.users;
create trigger on_auth_user_email_confirmed
  after update on auth.users
  for each row execute function public.handle_user_email_confirmed();

-- 2. posts -----------------------------------------------------------------
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  media_urls text[] not null default '{}',
  caption text,
  created_at timestamptz default now()
);
create index if not exists idx_posts_owner on public.posts (owner_id, created_at desc);
create index if not exists idx_posts_created on public.posts (created_at desc);

-- 3. reels -----------------------------------------------------------------
create table if not exists public.reels (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  video_url text not null,
  thumbnail_url text,
  caption text,
  likes_count integer not null default 0,
  created_at timestamptz default now()
);
create index if not exists idx_reels_created on public.reels (created_at desc);

-- 4. stories (24h expiry) --------------------------------------------------
create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  media_url text not null,
  media_type text check (media_type in ('image', 'video')) default 'image',
  expires_at timestamptz not null default (now() + interval '24 hours'),
  created_at timestamptz default now()
);
create index if not exists idx_stories_owner on public.stories (owner_id, created_at desc);
create index if not exists idx_stories_active on public.stories (expires_at);

-- 5. highlights (persistent story collections) -----------------------------
create table if not exists public.highlights (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  cover_url text,
  story_ids uuid[] not null default '{}',
  created_at timestamptz default now()
);

-- 6. chats + participants + messages --------------------------------------
create table if not exists public.chats (
  id uuid primary key default gen_random_uuid(),
  is_group boolean not null default false,
  title text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz default now()
);

create table if not exists public.chat_participants (
  chat_id uuid not null references public.chats(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member',
  joined_at timestamptz default now(),
  primary key (chat_id, user_id)
);
create index if not exists idx_chat_participants_user on public.chat_participants (user_id);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references public.chats(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  text text,
  media_url text,
  created_at timestamptz default now()
);
create index if not exists idx_messages_chat on public.messages (chat_id, created_at desc);

-- Helper for RLS: is the current user a participant of this chat?
create or replace function public.is_chat_participant(_chat_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1 from public.chat_participants
    where chat_id = _chat_id and user_id = auth.uid()
  );
$$;

-- =========================================================================
-- RLS
-- =========================================================================
alter table public.profiles           enable row level security;
alter table public.posts              enable row level security;
alter table public.reels              enable row level security;
alter table public.stories            enable row level security;
alter table public.highlights         enable row level security;
alter table public.chats              enable row level security;
alter table public.chat_participants  enable row level security;
alter table public.messages           enable row level security;

-- profiles: readable by everyone authenticated; writable only by owner
drop policy if exists "profiles_read_all"    on public.profiles;
drop policy if exists "profiles_insert_self" on public.profiles;
drop policy if exists "profiles_update_self" on public.profiles;
drop policy if exists "profiles_delete_self" on public.profiles;

create policy "profiles_read_all"
  on public.profiles for select
  to authenticated
  using (true);

create policy "profiles_insert_self"
  on public.profiles for insert
  to authenticated
  with check (id = auth.uid());

create policy "profiles_update_self"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

create policy "profiles_delete_self"
  on public.profiles for delete
  to authenticated
  using (id = auth.uid());

-- posts / reels / highlights: readable by all authed users, mutable by owner
do $$
declare tbl text;
begin
  foreach tbl in array array['posts','reels','highlights']
  loop
    execute format('drop policy if exists "%1$s_read_all"    on public.%1$s', tbl);
    execute format('drop policy if exists "%1$s_owner_write" on public.%1$s', tbl);
    execute format($f$
      create policy "%1$s_read_all"
        on public.%1$s for select to authenticated using (true)
    $f$, tbl);
    execute format($f$
      create policy "%1$s_owner_write"
        on public.%1$s for all to authenticated
        using (owner_id = auth.uid())
        with check (owner_id = auth.uid())
    $f$, tbl);
  end loop;
end $$;

-- stories: readable if not expired; owner may manage
drop policy if exists "stories_read_active" on public.stories;
drop policy if exists "stories_owner_write" on public.stories;

create policy "stories_read_active"
  on public.stories for select
  to authenticated
  using (expires_at > now() or owner_id = auth.uid());

create policy "stories_owner_write"
  on public.stories for all
  to authenticated
  using (owner_id = auth.uid())
  with check (owner_id = auth.uid());

-- chats: readable only by participants; creator owns write
drop policy if exists "chats_participant_read" on public.chats;
drop policy if exists "chats_creator_write"    on public.chats;

create policy "chats_participant_read"
  on public.chats for select
  to authenticated
  using (public.is_chat_participant(id));

create policy "chats_creator_write"
  on public.chats for all
  to authenticated
  using (created_by = auth.uid())
  with check (created_by = auth.uid());

-- chat_participants: user manages their own row; participants can see membership
drop policy if exists "chat_participants_self_read"   on public.chat_participants;
drop policy if exists "chat_participants_self_insert" on public.chat_participants;
drop policy if exists "chat_participants_self_delete" on public.chat_participants;

create policy "chat_participants_self_read"
  on public.chat_participants for select
  to authenticated
  using (user_id = auth.uid() or public.is_chat_participant(chat_id));

create policy "chat_participants_self_insert"
  on public.chat_participants for insert
  to authenticated
  with check (user_id = auth.uid());

create policy "chat_participants_self_delete"
  on public.chat_participants for delete
  to authenticated
  using (user_id = auth.uid());

-- messages: only participants can read/write; sender must equal auth.uid()
drop policy if exists "messages_participant_read" on public.messages;
drop policy if exists "messages_send"             on public.messages;
drop policy if exists "messages_sender_delete"    on public.messages;

create policy "messages_participant_read"
  on public.messages for select
  to authenticated
  using (public.is_chat_participant(chat_id));

create policy "messages_send"
  on public.messages for insert
  to authenticated
  with check (
    sender_id = auth.uid()
    and public.is_chat_participant(chat_id)
  );

create policy "messages_sender_delete"
  on public.messages for delete
  to authenticated
  using (sender_id = auth.uid());

-- =========================================================================
-- Storage: create a private 'media' bucket + per-user folder RLS
-- =========================================================================
insert into storage.buckets (id, name, public)
values ('media', 'media', false)
on conflict (id) do nothing;

drop policy if exists "media_owner_read"   on storage.objects;
drop policy if exists "media_owner_write"  on storage.objects;
drop policy if exists "media_public_read"  on storage.objects;
drop policy if exists "media_owner_delete" on storage.objects;

-- Any authenticated user can read media (feed images, avatars are shared).
create policy "media_public_read"
  on storage.objects for select
  to authenticated
  using (bucket_id = 'media');

-- Users can only upload into a folder named after their user id: media/<uid>/...
create policy "media_owner_write"
  on storage.objects for insert
  to authenticated
  with check (
    bucket_id = 'media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

create policy "media_owner_delete"
  on storage.objects for delete
  to authenticated
  using (
    bucket_id = 'media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
